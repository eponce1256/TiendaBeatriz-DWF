package sv.tienda.beatriz.www.entities;

import jakarta.persistence.*;

import java.util.Collection;

@Entity
@Table(name = "empleados", schema = "tiendabeatriz", catalog = "")
public class EmpleadosEntity {
    @Id
    @Column(name = "idEmpleado", nullable = false)
    private int idEmpleado;
    @Basic
    @Column(name = "nombre", nullable = false, length = 255)
    private String nombre;
    @Basic
    @Column(name = "cargo", nullable = false, length = 255)
    private String cargo;
    @OneToMany(mappedBy = "empleadosByIdEmpleado")
    private Collection<VentasEntity> ventasByIdEmpleado;

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        EmpleadosEntity that = (EmpleadosEntity) o;

        if (idEmpleado != that.idEmpleado) return false;
        if (nombre != null ? !nombre.equals(that.nombre) : that.nombre != null) return false;
        if (cargo != null ? !cargo.equals(that.cargo) : that.cargo != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = idEmpleado;
        result = 31 * result + (nombre != null ? nombre.hashCode() : 0);
        result = 31 * result + (cargo != null ? cargo.hashCode() : 0);
        return result;
    }

    public Collection<VentasEntity> getVentasByIdEmpleado() {
        return ventasByIdEmpleado;
    }

    public void setVentasByIdEmpleado(Collection<VentasEntity> ventasByIdEmpleado) {
        this.ventasByIdEmpleado = ventasByIdEmpleado;
    }
}
