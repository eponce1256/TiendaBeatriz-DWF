package sv.tienda.beatriz.www.managedbeans;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.bean.ManagedBean;
import jakarta.faces.bean.ViewScoped;
import jakarta.faces.context.FacesContext;


import sv.tienda.beatriz.www.entities.EmpleadosEntity;
import sv.tienda.beatriz.www.entities.VentasEntity;
import sv.tienda.beatriz.www.models.VentaModel;

import java.util.List;

@ManagedBean
@ViewScoped

public class VentaBean {
    public VentasEntity getVenta() {
        return venta;
    }

    public void setVenta(VentasEntity venta) {
        this.venta = venta;
    }

    private VentasEntity venta;
    private VentaModel modelo=new VentaModel();



    public VentaBean(){
        venta= new VentasEntity();
    }

    public List<VentasEntity> ListaVenta(){
        return modelo.listarVentas();}
}
