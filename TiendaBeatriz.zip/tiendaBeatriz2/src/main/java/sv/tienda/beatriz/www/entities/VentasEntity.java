package sv.tienda.beatriz.www.entities;

import jakarta.persistence.*;

import java.sql.Date;

@Entity
@Table(name = "ventas", schema = "tiendabeatriz", catalog = "")
public class VentasEntity {
    @Id
    @Column(name = "idVenta", nullable = false)
    private int idVenta;
    @Basic
    @Column(name = "cantidad", nullable = false)
    private int cantidad;
    @Basic
    @Column(name = "fecha", nullable = false)
    private Date fecha;
    @ManyToOne
    @JoinColumn(name = "idEmpleado", referencedColumnName = "idEmpleado")
    private EmpleadosEntity empleadosByIdEmpleado;
    @ManyToOne
    @JoinColumn(name = "idProducto", referencedColumnName = "idProducto")
    private ProductosEntity productosByIdProducto;

    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        VentasEntity that = (VentasEntity) o;

        if (idVenta != that.idVenta) return false;
        if (cantidad != that.cantidad) return false;
        if (fecha != null ? !fecha.equals(that.fecha) : that.fecha != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = idVenta;
        result = 31 * result + cantidad;
        result = 31 * result + (fecha != null ? fecha.hashCode() : 0);
        return result;
    }

    public EmpleadosEntity getEmpleadosByIdEmpleado() {
        return empleadosByIdEmpleado;
    }

    public void setEmpleadosByIdEmpleado(EmpleadosEntity empleadosByIdEmpleado) {
        this.empleadosByIdEmpleado = empleadosByIdEmpleado;
    }

    public ProductosEntity getProductosByIdProducto() {
        return productosByIdProducto;
    }

    public void setProductosByIdProducto(ProductosEntity productosByIdProducto) {
        this.productosByIdProducto = productosByIdProducto;
    }
}
