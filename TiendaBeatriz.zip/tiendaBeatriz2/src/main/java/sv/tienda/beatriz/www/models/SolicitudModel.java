package sv.tienda.beatriz.www.models;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Query;
import sv.tienda.beatriz.www.entities.ProductosEntity;
import sv.tienda.beatriz.www.entities.SolicitudesEntity;
import sv.tienda.beatriz.www.utils.JpaUtil;
import java.util.List;

import java.util.List;

public class SolicitudModel {

    public List<SolicitudesEntity> listarSolicitud() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            Query consulta = em.createQuery("SELECT S FROM SolicitudesEntity S");
            List<SolicitudesEntity> lista = consulta.getResultList();
            em.close();
            return lista;
        } catch (Exception e) {
            em.close();
            return null;
        }
    }
}
