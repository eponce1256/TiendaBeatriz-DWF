package sv.tienda.beatriz.www.managedbeans;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.bean.ManagedBean;
import jakarta.faces.bean.ViewScoped;
import jakarta.faces.context.FacesContext;


import sv.tienda.beatriz.www.entities.ProductosEntity;
import sv.tienda.beatriz.www.models.EntradaModel;

import java.util.List;

@ManagedBean
@ViewScoped
public class EntradaBean {
    private ProductosEntity producto;
    private EntradaModel modelo = new EntradaModel();

    public EntradaBean() {
        producto = new ProductosEntity();
    }

    public List<ProductosEntity> getProductos() {
        return modelo.listarProductos();
    }

    public String guardarProducto() {
        if (modelo.insertarProducto(producto) != 1) {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Error", "No se pudo insertar el producto");
            FacesContext.getCurrentInstance().addMessage(null, message);
        } else {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
                    "Éxito", "Producto registrado exitosamente");
            FacesContext.getCurrentInstance().addMessage(null, message);
            producto = new ProductosEntity(); // Limpiamos el objeto para futuros productos
        }
        return "";
    }

    public String editarProducto(ProductosEntity productoEditar) {
        producto = productoEditar;
        return "formEditar"; // Página para editar el producto
    }

    public String eliminarProducto(int id) {
        if (modelo.eliminarProducto(id) != 1) {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Error", "No se pudo eliminar el producto");
            FacesContext.getCurrentInstance().addMessage(null, message);
        } else {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
                    "Éxito", "Producto eliminado exitosamente");
            FacesContext.getCurrentInstance().addMessage(null, message);
        }
        return "";
    }

    public String modificarProducto() {
        if (modelo.modificarProducto(producto) != 1) {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Error", "No se pudo modificar el producto");
            FacesContext.getCurrentInstance().addMessage(null, message);
        } else {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
                    "Éxito", "Producto modificado exitosamente");
            FacesContext.getCurrentInstance().addMessage(null, message);
        }
        return "index"; // Página principal después de la modificación
    }

    // Getters y setters generados automáticamente
    public ProductosEntity getProducto() {
        return producto;
    }

    public void setProducto(ProductosEntity producto) {
        this.producto = producto;
    }
}