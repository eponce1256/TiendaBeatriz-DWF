package sv.tienda.beatriz.www.managedbeans;

import jakarta.faces.application.FacesMessage;
import jakarta.faces.bean.ManagedBean;
import jakarta.faces.bean.ViewScoped;
import jakarta.faces.context.FacesContext;


import sv.tienda.beatriz.www.entities.EmpleadosEntity;
import sv.tienda.beatriz.www.entities.ProductosEntity;
import sv.tienda.beatriz.www.entities.SolicitudesEntity;
import sv.tienda.beatriz.www.models.EmpleadoModel;
import sv.tienda.beatriz.www.models.SolicitudModel;

import java.util.List;

@ManagedBean
@ViewScoped

public class SolicitudBean {

    private SolicitudModel modelo=new SolicitudModel();

    public List<SolicitudesEntity> listarSolicitud(){
        return modelo.listarSolicitud();}
}
