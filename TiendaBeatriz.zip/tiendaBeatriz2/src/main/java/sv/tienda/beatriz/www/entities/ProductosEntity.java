package sv.tienda.beatriz.www.entities;

import jakarta.persistence.*;

import java.util.Collection;

@Entity
@Table(name = "productos", schema = "tiendabeatriz", catalog = "")
public class ProductosEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "idProducto", nullable = false)
    private int idProducto;
    @Basic
    @Column(name = "nombre", nullable = false, length = 255)
    private String nombre;
    @Basic
    @Column(name = "cantidad", nullable = false)
    private int cantidad;
    @OneToMany(mappedBy = "productosByIdProducto")
    private Collection<SolicitudesEntity> solicitudesByIdProducto;
    @OneToMany(mappedBy = "productosByIdProducto")
    private Collection<VentasEntity> ventasByIdProducto;

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ProductosEntity that = (ProductosEntity) o;

        if (idProducto != that.idProducto) return false;
        if (cantidad != that.cantidad) return false;
        if (nombre != null ? !nombre.equals(that.nombre) : that.nombre != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = idProducto;
        result = 31 * result + (nombre != null ? nombre.hashCode() : 0);
        result = 31 * result + cantidad;
        return result;
    }

    public Collection<SolicitudesEntity> getSolicitudesByIdProducto() {
        return solicitudesByIdProducto;
    }

    public void setSolicitudesByIdProducto(Collection<SolicitudesEntity> solicitudesByIdProducto) {
        this.solicitudesByIdProducto = solicitudesByIdProducto;
    }

    public Collection<VentasEntity> getVentasByIdProducto() {
        return ventasByIdProducto;
    }

    public void setVentasByIdProducto(Collection<VentasEntity> ventasByIdProducto) {
        this.ventasByIdProducto = ventasByIdProducto;
    }
}
