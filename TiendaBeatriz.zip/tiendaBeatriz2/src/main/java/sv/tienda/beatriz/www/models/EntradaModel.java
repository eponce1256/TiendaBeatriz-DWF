package sv.tienda.beatriz.www.models;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Query;
import sv.tienda.beatriz.www.entities.ProductosEntity;
import sv.tienda.beatriz.www.utils.JpaUtil;
import java.util.List;
public class EntradaModel {

    public List<ProductosEntity> listarProductos() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            Query consulta = em.createQuery("SELECT P FROM ProductosEntity P");
            List<ProductosEntity> lista = consulta.getResultList();
            em.close();
            return lista;
        } catch (Exception e) {
            em.close();
            return null;
        }
    }

    public ProductosEntity obtenerProducto(int id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            ProductosEntity producto = em.find(ProductosEntity.class, id);
            em.close();
            return producto;
        } catch (Exception e) {
            em.close();
            return null;
        }
    }

    public int insertarProducto(ProductosEntity producto) {
        EntityManager em = JpaUtil.getEntityManager();
        EntityTransaction tran = em.getTransaction();
        try {
            tran.begin();
            em.persist(producto);
            tran.commit();
            em.close();
            return 1;
        } catch (Exception e) {
            tran.rollback();
            em.close();
            return 0;
        }
    }

    public int modificarProducto(ProductosEntity producto) {
        EntityManager em = JpaUtil.getEntityManager();
        EntityTransaction tran = em.getTransaction();
        try {
            tran.begin();
            em.merge(producto);
            tran.commit();
            em.close();
            return 1;
        } catch (Exception e) {
            tran.rollback();
            em.close();
            return 0;
        }
    }

    public int eliminarProducto(int id) {
        EntityManager em = JpaUtil.getEntityManager();
        int filasBorradas = 0;
        try {
            ProductosEntity producto = em.find(ProductosEntity.class, id);
            if (producto != null) {
                EntityTransaction tran = em.getTransaction();
                tran.begin();
                em.remove(producto);
                tran.commit();
                filasBorradas = 1;
            }
            em.close();
            return filasBorradas;
        } catch (Exception e) {
            em.close();
            return 0;
        }
    }
}
