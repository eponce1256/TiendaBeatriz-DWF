package sv.tienda.beatriz.www.managedbeans;

import jakarta.faces.application.FacesMessage;
import jakarta.faces.bean.ManagedBean;
import jakarta.faces.bean.ViewScoped;
import jakarta.faces.context.FacesContext;


import sv.tienda.beatriz.www.entities.EmpleadosEntity;
import sv.tienda.beatriz.www.entities.ProductosEntity;
import sv.tienda.beatriz.www.models.EmpleadoModel;

import java.util.List;

@ManagedBean
@ViewScoped

public class EmpleadoBean {
    private EmpleadoModel modelo=new EmpleadoModel();

    public EmpleadosEntity getEmpleado() {
        return empleado;
    }

    public void setEmpleado(EmpleadosEntity empleado) {
        this.empleado = empleado;
    }

    private EmpleadosEntity empleado;

    public EmpleadoBean() {
        empleado = new EmpleadosEntity();
    }

    public List<EmpleadosEntity> ListaEmpleado(){
        return modelo.listarEmpleados();}
}
